/**
 * Elementor Copier - Paste Interceptor
 * Intercepts paste operations in the Elementor editor to inject extension data
 * 
 * This module captures paste events (keyboard shortcuts and UI actions) and
 * checks if the clipboard contains data from the Chrome extension. When detected,
 * it prevents the default paste behavior and injects the converted data.
 * 
 * Requirements: 7.1, 7.2, 7.3, 7.4
 */

class PasteInterceptor {
  constructor() {
    this.clipboardManager = null;
    this.editorDetector = null;
    this.initialized = false;
    this.keyboardListenerAttached = false;
    this.contextMenuListenerAttached = false;
  }

  /**
   * Initialize the paste interceptor
   * Requirement 7.1: Intercept paste events in editor context
   * 
   * @param {ClipboardManager} clipboardManager - Instance of clipboard manager
   * @param {ElementorEditorDetector} editorDetector - Instance of editor detector
   * @returns {Promise<boolean>} Success status
   */
  async initialize(clipboardManager, editorDetector) {
    try {
      if (this.initialized) {
        console.log('[Paste Interceptor] Already initialized');
        return true;
      }

      // Validate dependencies
      if (!clipboardManager || !editorDetector) {
        console.error('[Paste Interceptor] Missing required dependencies');
        return false;
      }

      this.clipboardManager = clipboardManager;
      this.editorDetector = editorDetector;

      // Wait for Elementor to be ready
      if (!this.editorDetector.isElementorEditor()) {
        console.log('[Paste Interceptor] Not in Elementor editor, skipping initialization');
        return false;
      }

      console.log('[Paste Interceptor] Initializing in Elementor editor...');

      // Attach keyboard event listeners
      this.attachKeyboardListeners();

      this.initialized = true;
      console.log('✓ Paste interceptor initialized');
      return true;

    } catch (error) {
      console.error('[Paste Interceptor] Initialization error:', error);
      return false;
    }
  }

  /**
   * Attach keyboard event listeners for paste shortcuts
   * Requirement 7.2: Listen for Ctrl+V and Cmd+V
   */
  attachKeyboardListeners() {
    if (this.keyboardListenerAttached) {
      return;
    }

    // Listen for keydown events on the document
    document.addEventListener('keydown', this.handleKeyboardPaste.bind(this), true);
    
    // Also listen on the Elementor editor iframe if it exists
    this.attachEditorIframeListeners();

    this.keyboardListenerAttached = true;
    console.log('✓ Keyboard paste listeners attached');
  }

  /**
   * Attach listeners to Elementor editor iframe
   */
  attachEditorIframeListeners() {
    try {
      // Elementor editor typically uses an iframe for the preview
      const editorFrame = document.querySelector('#elementor-preview-iframe');
      
      if (editorFrame && editorFrame.contentWindow) {
        const frameDocument = editorFrame.contentWindow.document;
        frameDocument.addEventListener('keydown', this.handleKeyboardPaste.bind(this), true);
        console.log('✓ Editor iframe paste listeners attached');
      }
    } catch (error) {
      // Cross-origin iframe access may fail, which is expected
      console.log('[Paste Interceptor] Could not attach to iframe (may be cross-origin)');
    }
  }

  /**
   * Handle keyboard paste events (Ctrl+V, Cmd+V)
   * Requirement 7.2: Intercept keyboard paste shortcuts
   * 
   * @param {KeyboardEvent} event - The keyboard event
   */
  async handleKeyboardPaste(event) {
    try {
      // Check if this is a paste shortcut
      // Ctrl+V (Windows/Linux) or Cmd+V (Mac)
      const isPasteShortcut = (event.ctrlKey || event.metaKey) && 
                              event.key.toLowerCase() === 'v' &&
                              !event.shiftKey && 
                              !event.altKey;

      if (!isPasteShortcut) {
        return;
      }

      console.log('[Paste Interceptor] Paste shortcut detected');

      // Check if we should handle this paste
      const shouldHandle = await this.shouldHandlePaste();

      if (!shouldHandle) {
        console.log('[Paste Interceptor] No extension data in clipboard, allowing default paste');
        return;
      }

      // Prevent default paste behavior
      // Requirement 7.4: Prevent default when extension data is detected
      event.preventDefault();
      event.stopPropagation();
      event.stopImmediatePropagation();

      console.log('✓ Paste event intercepted, extension data detected');

      // Read extension data from clipboard
      const extensionData = await this.clipboardManager.readExtensionData();

      if (!extensionData) {
        console.warn('[Paste Interceptor] Failed to read extension data after detection');
        return;
      }

      // Trigger paste with extension data
      await this.triggerExtensionPaste(extensionData);

    } catch (error) {
      console.error('[Paste Interceptor] Error handling keyboard paste:', error);
    }
  }

  /**
   * Check if paste should be handled by the extension
   * Requirement 7.3: Check for extension clipboard data
   * 
   * @returns {Promise<boolean>} True if extension should handle paste
   */
  async shouldHandlePaste() {
    try {
      // Check if we're in preview mode (should not intercept)
      if (this.editorDetector.isPreviewMode()) {
        console.log('[Paste Interceptor] In preview mode, skipping interception');
        return false;
      }

      // Check if clipboard contains extension data
      const hasExtensionData = await this.clipboardManager.hasExtensionData();

      return hasExtensionData;

    } catch (error) {
      console.error('[Paste Interceptor] Error checking clipboard:', error);
      return false;
    }
  }

  /**
   * Trigger paste operation with extension data
   * This will be enhanced in future tasks to actually inject into Elementor
   * 
   * @param {Object} extensionData - The extension clipboard data
   */
  async triggerExtensionPaste(extensionData) {
    try {
      console.log('[Paste Interceptor] Triggering extension paste with data:', extensionData);

      // For now, just log the data
      // Future tasks will implement the actual Elementor injection
      console.log('Extension data type:', extensionData.elementType);
      console.log('Extension data version:', extensionData.version);
      
      // Show notification to user
      this.showPasteNotification(extensionData);

      // TODO: Task 5 will implement editor context injection
      // TODO: Task 2 will implement format conversion
      // For now, we just prevent the default paste and log

    } catch (error) {
      console.error('[Paste Interceptor] Error triggering paste:', error);
      this.showErrorNotification('Failed to paste element. Please try again.');
    }
  }

  /**
   * Show notification to user about paste operation
   * 
   * @param {Object} extensionData - The extension clipboard data
   */
  showPasteNotification(extensionData) {
    const elementType = extensionData.elementType || 'element';
    const message = `Extension data detected: ${elementType}. Native paste will be implemented in upcoming tasks.`;
    
    console.log(`[Paste Interceptor] ${message}`);
    
    // Create a simple notification element
    const notification = document.createElement('div');
    notification.style.cssText = `
      position: fixed;
      top: 20px;
      right: 20px;
      background: #4CAF50;
      color: white;
      padding: 16px 24px;
      border-radius: 4px;
      box-shadow: 0 2px 8px rgba(0,0,0,0.2);
      z-index: 999999;
      font-family: Arial, sans-serif;
      font-size: 14px;
      max-width: 400px;
    `;
    notification.textContent = message;
    
    document.body.appendChild(notification);
    
    // Remove after 5 seconds
    setTimeout(() => {
      notification.style.transition = 'opacity 0.3s';
      notification.style.opacity = '0';
      setTimeout(() => {
        if (notification.parentNode) {
          notification.parentNode.removeChild(notification);
        }
      }, 300);
    }, 5000);
  }

  /**
   * Show error notification to user
   * 
   * @param {string} message - Error message
   */
  showErrorNotification(message) {
    console.error(`[Paste Interceptor] ${message}`);
    
    const notification = document.createElement('div');
    notification.style.cssText = `
      position: fixed;
      top: 20px;
      right: 20px;
      background: #f44336;
      color: white;
      padding: 16px 24px;
      border-radius: 4px;
      box-shadow: 0 2px 8px rgba(0,0,0,0.2);
      z-index: 999999;
      font-family: Arial, sans-serif;
      font-size: 14px;
      max-width: 400px;
    `;
    notification.textContent = message;
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
      notification.style.transition = 'opacity 0.3s';
      notification.style.opacity = '0';
      setTimeout(() => {
        if (notification.parentNode) {
          notification.parentNode.removeChild(notification);
        }
      }, 300);
    }, 5000);
  }

  /**
   * Cleanup and remove event listeners
   */
  cleanup() {
    if (this.keyboardListenerAttached) {
      document.removeEventListener('keydown', this.handleKeyboardPaste.bind(this), true);
      this.keyboardListenerAttached = false;
    }

    this.initialized = false;
    console.log('[Paste Interceptor] Cleaned up');
  }
}

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
  module.exports = { PasteInterceptor };
}

// Make available globally for content scripts
if (typeof window !== 'undefined') {
  window.PasteInterceptor = PasteInterceptor;
}
