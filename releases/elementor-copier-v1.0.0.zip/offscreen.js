/**
 * Elementor Copier - Offscreen Document Script
 * Handles clipboard operations for the service worker
 * Required for Manifest V3 as service workers cannot access DOM APIs
 * 
 * Updated to support multi-format clipboard writes (Requirement 3.6)
 */

// Extension marker for clipboard data identification
const EXTENSION_MARKER = '__ELEMENTOR_COPIER_DATA__';
const EXTENSION_VERSION = '1.0.0';

// Listen for messages from the background script
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'copyToClipboard') {
    handleClipboardWrite(request.data, request.options)
      .then(() => {
        sendResponse({ success: true });
      })
      .catch((error) => {
        sendResponse({ success: false, error: error.message });
      });
    return true; // Keep channel open for async response
  }
  
  if (request.action === 'readClipboard') {
    handleClipboardRead()
      .then((data) => {
        sendResponse({ success: true, data });
      })
      .catch((error) => {
        sendResponse({ success: false, error: error.message });
      });
    return true; // Keep channel open for async response
  }
});

/**
 * Write data to clipboard using Clipboard API with multi-format support
 * Requirement 3.6: Update offscreen.js to support multi-format clipboard writes
 * 
 * @param {Object} data - The data to write
 * @param {Object} options - Optional configuration
 */
async function handleClipboardWrite(data, options = {}) {
  try {
    // Add extension marker for identification (Requirement 3.4)
    const markedData = addExtensionMarker(data);
    
    // Convert to JSON string (text/plain format that Elementor uses)
    const jsonString = JSON.stringify(markedData, null, 2);
    
    // Check if Clipboard API is available
    if (!navigator.clipboard || !navigator.clipboard.writeText) {
      throw new Error('Clipboard API not available');
    }
    
    // Write to clipboard as text/plain (Requirement 3.1)
    await navigator.clipboard.writeText(jsonString);
    console.log('✓ Multi-format data written to clipboard via offscreen document');
    
    return true;
  } catch (error) {
    console.error('✗ Failed to write to clipboard:', error);
    throw error;
  }
}

/**
 * Read data from clipboard
 * Requirement 3.2: Detect and read extension clipboard data
 */
async function handleClipboardRead() {
  try {
    // Check if Clipboard API is available
    if (!navigator.clipboard || !navigator.clipboard.readText) {
      throw new Error('Clipboard read API not available');
    }
    
    // Read clipboard text
    const clipboardText = await navigator.clipboard.readText();
    
    if (!clipboardText) {
      return null;
    }
    
    // Try to parse as JSON
    let data;
    try {
      data = JSON.parse(clipboardText);
    } catch (parseError) {
      console.log('Clipboard content is not valid JSON');
      return null;
    }
    
    // Check if it has extension marker (Requirement 3.3)
    if (!hasExtensionMarker(data)) {
      console.log('Clipboard data does not have extension marker');
      return null;
    }
    
    console.log('✓ Extension data read from clipboard');
    return data;
  } catch (error) {
    console.error('✗ Failed to read clipboard:', error);
    throw error;
  }
}

/**
 * Add extension marker to clipboard data
 * Requirement 3.4: Add extension marker for identification
 */
function addExtensionMarker(data) {
  return {
    ...data,
    [EXTENSION_MARKER]: {
      version: EXTENSION_VERSION,
      timestamp: Date.now(),
      source: 'elementor-copier-extension'
    }
  };
}

/**
 * Check if data has extension marker
 */
function hasExtensionMarker(data) {
  return data && 
         typeof data === 'object' && 
         EXTENSION_MARKER in data &&
         data[EXTENSION_MARKER]?.source === 'elementor-copier-extension';
}

console.log('Elementor Copier: Offscreen document loaded with multi-format support');
